EVE QUINN / LITTLE MOUSE: PDP-1 ADVENTURE STOCK-SIMH PATCH
Prepared for Bill Ezell, 2026-11-02.

Base repository: https://github.com/wjenh/pidp1-mods
Base commit: caa0c76a024cc945780db1376b983747450f85ac
  (includes the SHRDLU release)
Eve's private working commit: 57f7357894a0a08ce859d8ee16b8b8693e57a250

The patch includes nine files: the guarded native/stock-SIMH DCS
compatibility code, Adventure build/start INI, documentation, and an
automated interactive smoke test. Native DCS2 behavior remains guarded.

Apply from a CLEAN checkout at the above base commit:
  git apply --check adventure-stock-simh.patch
  git apply adventure-stock-simh.patch

Build from FunStuff/Adventure (AM1 and its includes must be installed):
  make adventure-simh AM1="am1 -I ${PWD}/../../Am1Includes"
  make adventure.rim AM1="am1 -I ${PWD}/../../Am1Includes"

Return to repository root and smoke-test the stock simulator:
  python3 tests/run_adventure_simh_smoke.py --simh /path/to/stock-SIMH/BIN/pdp1

Verified 2026-11-02:
  Both Adventure RIM assemblies passed on current pidp1-mods.
  Stock SIMH 698dc8a1b2135ab03f1da0be9ee44b5f1beeadc6:
  greeting, NO, starting road, INVENTORY response passed via real TCP
  Type 630 DCS with CR/LF commands.
Not certified: full gameplay, saves, or native physical PiDP-1 hardware.
No binaries, private data or credentials inside this archive.
